$(document).ready(function(){
  $('.slider').slider({full_width: true});
});

$(document).ready(function(){
  $('.carousel').carousel();
});

$(document).ready(function(){
  $('.fixed-action-btn').floatingActionButton();
});