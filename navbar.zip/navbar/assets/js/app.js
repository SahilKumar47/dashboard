$('.js--wp-1').waypoint(function(direction){
    $('.js--wp-1').addClass('animated fadeIn');
},{
    offset: '50%'
});

$('.js--1').waypoint(function(direction){
    $('.js--1').addClass('animated fadeInUpBig');
}, {
    offset: '70%'
}
);

$('.js--2').waypoint(function(direction){
    $('.js--2').addClass('animated bounceInLeft');
}, {
    offset: '50%'
}
);


$('.js--3').waypoint(function(direction){
    $('.js--3').addClass('animated bounceInRight');
}, {
    offset: '50%'
}
);

$('.js--4').waypoint(function(direction){
    $('.js--4').addClass('animated slideInUp');
}, {
    offset: '50%'
}
);

$('.js--5').waypoint(function(direction){
    $('.js--5').addClass('animated slideInDown');
}, {
    offset: '50%'
}
);