(function($){
    
    $(document).ready(function(){
    
        $(".pagination").customPaginate({
        
            itemsToPaginate : ".posts",
			
			activeClass : "active-class"
        
        });
    
    });
    
})(jQuery)
